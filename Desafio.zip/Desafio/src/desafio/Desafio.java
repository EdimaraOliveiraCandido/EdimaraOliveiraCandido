/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafio;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Edimara Oliveira
 */
public class Desafio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
int numero1;
int numero2;
int soma;
int multi;

    Scanner teclado= new Scanner(System.in);
        numero1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o Primeiro número inteiro"));
        numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o Segundo número inteiro"));
        soma = numero1 + numero2;
        multi = numero1 * numero2;
        
        if(numero1 == numero2) {
        JOptionPane.showMessageDialog(null,"O número " + numero1 + " é igual ao número " + numero2 + " e o resultado da soma é " + soma);
    } 
        else if (numero1 != numero2) {
        JOptionPane.showMessageDialog(null,"O número " + numero1 + " é diferente do número " + numero2 + " e o resultado da multiplicação é " + multi);
    } 
  }
}